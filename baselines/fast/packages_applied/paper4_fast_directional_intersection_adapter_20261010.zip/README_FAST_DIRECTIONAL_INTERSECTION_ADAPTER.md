# FAST directional-word intersection adapter

This overlay keeps the authors' published FIF files unchanged and applies one
deterministic input adapter at read time.

## Audited grids

- Russian: case-insensitive 34-channel intersection across all 12 subjects;
  half-open window `[0.0, 1.0)` seconds; 250 Hz; 250 samples.
- Spanish: case-insensitive 38-channel intersection across all 10 subjects;
  half-open window `[-0.5, 1.0)` seconds; 500 Hz; 750 samples.
- Russian 500 Hz records are anti-alias resampled with
  `scipy.signal.resample_poly`; the published 250 Hz `sub9` record is not
  resampled.
- Channel order is fixed from the first published subject of each language and
  reused in every LOSO fold. Case-only spelling differences are normalized.
- All 12 Russian and all 10 Spanish subjects remain in calibrated LOSO.

The output root is new (`fast_native_dim32_harmonized_v1`) so results from an
older or partially completed run cannot be mixed with this run.

## Install and verify on AutoDL

Run from `/root/autodl-tmp/paper4` after uploading the zip to
`/root/autodl-tmp` or the project directory:

```bash
cd /root/autodl-tmp/paper4

PATCH_ZIP="$(find /root/autodl-tmp -maxdepth 3 -type f \
  -name 'paper4_fast_directional_intersection_adapter_20261010.zip' \
  -print -quit)"

test -n "$PATCH_ZIP" || {
  echo "ERROR: patch zip not found"
  exit 1
}

sha256sum "$PATCH_ZIP"
unzip -o "$PATCH_ZIP" -d /root/autodl-tmp/paper4

export PYTHONPATH=/root/autodl-tmp/paper4/src:/root/autodl-tmp/paper4:${PYTHONPATH:-}

python -m pytest -q \
  addition/tests/test_fast_native_fullcheck.py \
  addition/tests/test_directional_words_intersection_adapter.py

python -u addition/preflight_fast_native.py
mkdir -p logs
python -u addition/check_fast_dataset_inputs.py \
  2>&1 | tee logs/fast_directional_intersection_input_check.log
```

Do not start training unless the input check prints both of these lines:

```text
DATA_OK name=russian ... shape=(34,250) sfreq=250 classes=6 ...
DATA_OK name=spanish ... shape=(38,750) sfreq=500 classes=6 ...
```

The check must also finish with its normal success message and no traceback.

## Single-GPU plan and run

```bash
python -u addition/dispatch_fast_native.py --gpus 0 --plan

nohup python -u addition/dispatch_fast_native.py --gpus 0 \
  > logs/fast_native_dim32_harmonized_v1_launcher.log 2>&1 < /dev/null &

echo "launcher PID=$!"
tail -f logs/fast_native_dim32_harmonized_v1_launcher.log
```

This dispatches 36 sequential fits on GPU 0: ds003626 10, Russian 12,
Spanish 10, and Bimodal 4.
