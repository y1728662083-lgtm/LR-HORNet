# FAST input checker record-count hotfix

This hotfix changes only `addition/check_fast_dataset_inputs.py`.

It fixes the checker confusing subjects with subject-session records. For
`ds003626`, 10 subjects and 3 configured sessions correctly produce 30 loaded
records. The checker now verifies:

- exact configured-subject coverage; and
- for datasets with an explicit session list, exactly
  `number_of_subjects * number_of_sessions` records.

No dataset reader, channel adapter, split, model, optimizer, or training
configuration is changed.
