# FAST input checker subject-ID hotfix

This hotfix changes only `addition/check_fast_dataset_inputs.py`.

It fixes the checker confusing subjects with subject-session records. For
`ds003626`, 10 subjects and 3 configured sessions correctly produce 30 loaded
records. It also treats numeric spellings such as `1`, `01`, and `sub-01` as
the same subject ID, while leaving dataset-qualified IDs such as
`russian/sub1` unchanged. The checker verifies:

- exact configured-subject coverage; and
- for datasets with an explicit session list, exactly
  `number_of_subjects * number_of_sessions` records.

No dataset reader, channel adapter, split, model, optimizer, or training
configuration is changed.
